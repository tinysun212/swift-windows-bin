SWIFT FOR MSVC
==============

Environment
-----------
This archive is for TEST only under Windows 10 64bit.
This build requires the 'Visual C++ Redistributable for Visual Studio 2015'.

Install
-------
Copy 'Swift' directory to 'Program Files' directory.
Add path environment 'C:/Program Files/Swift/bin'.

Run
---
You can run only the interpreter.
ex) swift -O Hello.swift

Notice
------
Only working in INTERPRETE mode with the '-O' option.
Source: https://github.com/tinysun212/swift-windows/releases/tag/swift-msvc-20160401
